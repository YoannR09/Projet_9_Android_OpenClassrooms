package com.openclassrooms.realestatemanager.domain.repositories

import android.arch.lifecycle.LiveData
import com.openclassrooms.realestatemanager.data.dao.PropertiesDao
import com.openclassrooms.realestatemanager.data.dao.entities.PropertyEntity

class PropertyRepository(private val dao: PropertiesDao) {

    fun getList(): LiveData<List<PropertyEntity>> {
        return this.dao.list
    }
}