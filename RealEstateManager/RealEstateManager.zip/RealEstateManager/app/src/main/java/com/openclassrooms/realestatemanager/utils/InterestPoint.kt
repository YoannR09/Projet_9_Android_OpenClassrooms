package com.openclassrooms.realestatemanager.utils

enum class InterestPoint {
    SCHOOL,
    PARK,
    SHOP,
    TRANSPORT
}