package com.openclassrooms.realestatemanager.domain.usecases.property

import android.arch.lifecycle.LiveData
import android.content.Context
import com.openclassrooms.realestatemanager.data.dao.entities.PropertyEntity
import com.openclassrooms.realestatemanager.domain.repositories.Repository

class GetPropertyListUseCase {
    fun getList(context: Context): LiveData<List<PropertyEntity>> {
        return Repository.getPropertyRepository(context)!!.getList()
    }
}