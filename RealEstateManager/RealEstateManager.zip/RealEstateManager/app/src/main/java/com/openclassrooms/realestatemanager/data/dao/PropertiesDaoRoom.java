package com.openclassrooms.realestatemanager.data.dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Query;

import com.openclassrooms.realestatemanager.data.dao.entities.PropertyEntity;

import java.util.List;

@Dao
public interface PropertiesDaoRoom extends PropertiesDao {

    @Query("SELECT * FROM property")
    LiveData<List<PropertyEntity>> getList();
}
