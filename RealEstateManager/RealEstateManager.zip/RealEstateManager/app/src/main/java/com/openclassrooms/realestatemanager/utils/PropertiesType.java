package com.openclassrooms.realestatemanager.utils;

public enum PropertiesType {
    APARTMENT,
    LOFT,
    MANOR,
    HOUSE,
    STUDIO;
}
