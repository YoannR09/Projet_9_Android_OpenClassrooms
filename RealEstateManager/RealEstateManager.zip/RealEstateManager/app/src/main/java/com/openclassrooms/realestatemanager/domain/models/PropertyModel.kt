package com.openclassrooms.realestatemanager.domain.models

data class PropertyModel (
        val name: String
)
