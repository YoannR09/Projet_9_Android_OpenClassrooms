package com.openclassrooms.realestatemanager.data.dao;

import android.arch.lifecycle.LiveData;

import com.openclassrooms.realestatemanager.data.dao.entities.PropertyEntity;

import java.util.List;

public interface PropertiesDao {
    LiveData<List<PropertyEntity>> getList();
}
